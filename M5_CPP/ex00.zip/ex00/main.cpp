#include "Bureaucrat.hpp"
#include "utils/utils.hpp"

int main()
{
	// try {
	// 	0 
	// }
	// catch {

	// }
	Bureaucrat robot("Bob", 40);
	Bureaucrat robot1;
	robot1 = robot;
	return (0);
}